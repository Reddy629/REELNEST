const VIDEO_URL = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
const lectures = [
  {id:"cs1",title:"Graph Traversals: BFS & DFS",topic:"Data Structures & Algorithms",dept:"Computer Science",prof:"Prof. A. Sharma",duration:"38 min",mins:38,level:"Core",icon:"fa-diagram-project",color:"red",transcript:[["00:00","Today we explore graph traversal and why it matters."],["00:38","A graph contains vertices connected by edges."],["01:15","Breadth-first search explores level by level using a queue."],["02:05","Depth-first search explores deeply using a stack or recursion."],["03:00","Choose the traversal based on the problem structure."]]},
  {id:"cs2",title:"Dijkstra's Shortest Path",topic:"Advanced Algorithms",dept:"Computer Science",prof:"Dr. N. Rao",duration:"42 min",mins:42,level:"Advanced",icon:"fa-route",transcript:[["00:00","Shortest path problems appear in networks and maps."],["00:45","Dijkstra's algorithm uses a greedy strategy."],["01:30","The distance table stores the best known path."],["02:20","A priority queue helps select the closest unvisited node."]]},
  {id:"cs3",title:"Object Oriented Programming",topic:"Programming in C++",dept:"Computer Science",prof:"Prof. K. Reddy",duration:"35 min",mins:35,level:"Core",icon:"fa-cubes",transcript:[["00:00","Object oriented programming models software as objects."],["00:50","Classes define data and behavior."],["01:40","Encapsulation protects an object's internal state."],["02:30","Inheritance and polymorphism support reuse."]]},
  {id:"cs4",title:"Database Design & SQL",topic:"Database Systems",dept:"Computer Science",prof:"Dr. P. Mehta",duration:"31 min",mins:31,level:"Core",icon:"fa-database",transcript:[["00:00","A relational database stores data in tables."],["00:50","Keys define relationships between records."],["01:45","Normalization reduces unnecessary duplication."],["02:35","SQL queries retrieve and update information."]]},
  {id:"math1",title:"Linear Algebra: Eigenvalues",topic:"Engineering Mathematics",dept:"Mathematics",prof:"Dr. S. Iyer",duration:"46 min",mins:46,level:"Advanced",icon:"fa-square-root-variable",transcript:[["00:00","Linear algebra studies vectors and transformations."],["00:55","An eigenvector keeps its direction after transformation."],["01:45","The eigenvalue describes the scaling factor."],["02:35","Characteristic equations help us find eigenvalues."]]},
  {id:"math2",title:"Differential Equations",topic:"Engineering Mathematics",dept:"Mathematics",prof:"Prof. M. Das",duration:"40 min",mins:40,level:"Core",icon:"fa-function",transcript:[["00:00","Differential equations connect a function with its derivatives."],["00:50","Order is determined by the highest derivative."],["01:40","Initial conditions help identify a particular solution."]]},
  {id:"math3",title:"Fourier Series Essentials",topic:"Applied Mathematics",dept:"Mathematics",prof:"Dr. V. Kumar",duration:"33 min",mins:33,level:"Core",icon:"fa-wave-square",transcript:[["00:00","Periodic functions can be represented using sine and cosine."],["00:50","Fourier coefficients measure each frequency contribution."],["01:45","Symmetry can simplify the coefficient calculations."]]},
  {id:"math4",title:"Probability & Distributions",topic:"Engineering Statistics",dept:"Mathematics",prof:"Prof. R. Nair",duration:"29 min",mins:29,level:"Core",icon:"fa-chart-line",transcript:[["00:00","Probability quantifies uncertainty."],["00:50","A random variable maps outcomes to numerical values."],["01:40","Distributions describe the behavior of random variables."]]},
  {id:"mech1",title:"Laws of Thermodynamics",topic:"Thermal Engineering",dept:"Mechanical",prof:"Dr. R. Menon",duration:"44 min",mins:44,level:"Core",icon:"fa-temperature-half",transcript:[["00:00","Thermodynamics studies energy, heat and work."],["00:55","The first law expresses conservation of energy."],["01:50","The second law introduces entropy and direction."]]},
  {id:"mech2",title:"Fluid Mechanics: Flow",topic:"Fluid Mechanics",dept:"Mechanical",prof:"Prof. D. Singh",duration:"37 min",mins:37,level:"Core",icon:"fa-water",transcript:[["00:00","Fluid mechanics studies liquids and gases at rest and in motion."],["00:55","Pressure and velocity are key flow properties."],["01:50","Bernoulli's equation relates pressure, speed and height."]]},
  {id:"mech3",title:"Strength of Materials",topic:"Mechanics",dept:"Mechanical",prof:"Dr. A. Thomas",duration:"36 min",mins:36,level:"Advanced",icon:"fa-gears",transcript:[["00:00","Materials deform when forces are applied."],["00:50","Stress is force per unit area."],["01:40","Strain measures deformation relative to original size."]]},
  {id:"mech4",title:"Manufacturing Processes",topic:"Production Engineering",dept:"Mechanical",prof:"Prof. J. Paul",duration:"32 min",mins:32,level:"Core",icon:"fa-industry",transcript:[["00:00","Manufacturing converts raw materials into useful products."],["00:50","Casting forms parts using a mould."],["01:40","Machining removes material to achieve a desired shape."]]},
  {id:"elec1",title:"Digital Signal Processing",topic:"Signal Systems",dept:"Electronics",prof:"Dr. T. Bose",duration:"41 min",mins:41,level:"Advanced",icon:"fa-wave-square",transcript:[["00:00","Digital signal processing works with sampled signals."],["00:50","Sampling converts a continuous signal into discrete values."],["01:40","The Fourier transform reveals frequency components."]]},
  {id:"elec2",title:"Semiconductor Fundamentals",topic:"Electronic Devices",dept:"Electronics",prof:"Prof. L. Joseph",duration:"34 min",mins:34,level:"Core",icon:"fa-microchip",transcript:[["00:00","Semiconductors have conductivity between conductors and insulators."],["00:50","Doping changes the carrier concentration."],["01:40","A PN junction forms the basis of a diode."]]},
  {id:"elec3",title:"Network Analysis Basics",topic:"Circuit Theory",dept:"Electronics",prof:"Dr. B. Rao",duration:"30 min",mins:30,level:"Core",icon:"fa-plug",transcript:[["00:00","Circuit analysis helps determine current and voltage."],["00:50","Kirchhoff's current law follows charge conservation."],["01:40","Kirchhoff's voltage law follows energy conservation."]]},
  {id:"elec4",title:"Microcontroller Architecture",topic:"Embedded Systems",dept:"Electronics",prof:"Prof. S. Verma",duration:"39 min",mins:39,level:"Advanced",icon:"fa-memory",transcript:[["00:00","A microcontroller combines a processor, memory and peripherals."],["00:50","The CPU fetches, decodes and executes instructions."],["01:40","Timers and input-output pins connect the device to the world."]]}
];
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const store = {
  get(key, fallback){try{return JSON.parse(localStorage.getItem("reelnest_"+key)) ?? fallback}catch{return fallback}},
  set(key,value){localStorage.setItem("reelnest_"+key,JSON.stringify(value))}
};
let history = store.get("history",{}), notes = store.get("notes",{}), bookmarks = store.get("bookmarks",[]);
let activeLecture = null, activeFilter = "All", searchTerm = "", saveTimer = null, currentPlayerTab = "notes";

function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function formatTime(seconds){seconds=Math.max(0,Math.floor(seconds||0));return `${String(Math.floor(seconds/60)).padStart(2,"0")}:${String(seconds%60).padStart(2,"0")}`;}
function toast(message){$("#toastMessage").textContent=message;$("#toast").classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>$("#toast").classList.remove("show"),2300);}
function getLecture(id){return lectures.find(l=>l.id===id);}
function updateStats(){
  $("#statNotes").textContent=Object.values(notes).reduce((n,a)=>n+a.length,0);
  $("#statBookmarks").textContent=bookmarks.length;$("#bookmarkCount").textContent=bookmarks.length;
  $("#noteTabCount").textContent=(notes[activeLecture?.id]||[]).length;$("#bookmarkTabCount").textContent=bookmarks.filter(b=>b.lectureId===activeLecture?.id).length;
}
function matches(l){const hay=[l.title,l.topic,l.dept,l.prof,l.id].join(" ").toLowerCase();return (!searchTerm||hay.includes(searchTerm))&&(activeFilter==="All"||l.dept===activeFilter);}
function renderCatalog(){
  const depts=["Computer Science","Mathematics","Mechanical","Electronics"];
  const icons={"Computer Science":"fa-code","Mathematics":"fa-square-root-variable","Mechanical":"fa-gears","Electronics":"fa-microchip"};
  let visible=0;
  $("#lectureRows").innerHTML=depts.map(dept=>{
    const list=lectures.filter(l=>l.dept===dept&&matches(l));if(!list.length)return "";visible+=list.length;
    return `<section class="lecture-row"><div class="row-heading"><h3>${dept}<span>${String(list.length).padStart(2,"0")} LECTURES</span></h3><button data-dept-filter="${dept}">View collection <i class="fa-solid fa-arrow-right"></i></button></div><div class="lecture-scroller">${list.map((l,i)=>`<article class="lecture-card" data-lecture="${l.id}" tabindex="0" role="button" aria-label="Play ${escapeHTML(l.title)}"><div class="lecture-art" style="background:linear-gradient(135deg,${["#31141d","#171d32","#182c29","#2b1d31"][depts.indexOf(dept)]},#111116)"><span class="art-number">RN / ${String(i+1).padStart(2,"0")}</span><i class="fa-solid ${l.icon}"></i><span class="art-duration">${l.duration}</span></div><div class="lecture-card-body"><span class="lecture-category">${l.topic}</span><h4>${escapeHTML(l.title)}</h4><p>${escapeHTML(l.prof)} · ${l.level}</p><div class="lecture-card-footer"><span><i class="fa-regular fa-circle-play"></i> Lecture</span><span class="card-play"><i class="fa-solid fa-play"></i></span></div></div></article>`).join("")}</div></section>`;
  }).join("");
  $("#noResults").classList.toggle("hidden",visible>0);
  $$(".lecture-card").forEach(card=>{card.addEventListener("click",()=>openPlayer(card.dataset.lecture));card.addEventListener("keydown",e=>{if(e.key==="Enter")openPlayer(card.dataset.lecture)})});
  $$("[data-dept-filter]").forEach(btn=>btn.addEventListener("click",()=>{activeFilter=btn.dataset.deptFilter;updateFilterButtons();renderCatalog()}));
}
function updateFilterButtons(){$$(".filter-tab").forEach(b=>b.classList.toggle("active",b.dataset.filter===activeFilter));}
function renderContinue(){
  const items=Object.entries(history).filter(([id,h])=>h.time>2).sort((a,b)=>b[1].updated-a[1].updated).slice(0,3);
  $("#continueGrid").innerHTML=items.length?items.map(([id,h])=>{const l=getLecture(id);if(!l)return "";const pct=Math.min(100,Math.round((h.time/Math.max(h.duration,1))*100));return `<article class="continue-card" data-resume="${id}"><div class="continue-thumb"><i class="fa-solid ${l.icon}"></i></div><div class="continue-details"><small>${l.dept.toUpperCase()}</small><b>${escapeHTML(l.title)}</b><span>Resume at ${formatTime(h.time)}</span><div class="progress-track"><i style="width:${pct}%"></i></div></div></article>`}).join(""):`<div class="empty-state"><i class="fa-solid fa-hourglass-start"></i><span>Your learning journey starts here</span><small>Play a lecture and your progress will appear here.</small></div>`;
  $$("[data-resume]").forEach(c=>c.addEventListener("click",()=>openPlayer(c.dataset.resume,true)));
}
function openPlayer(id,resume=false){
  const l=getLecture(id);if(!l)return;activeLecture=l;$("#playerTitle").textContent=l.title;$("#overlayTitle").textContent=l.title;$("#playerSubtitle").textContent=l.topic;$("#playerDepartment").textContent=l.dept.toUpperCase();$("#playerProfessor").textContent=`${l.prof} · ${l.duration}`;
  const video=$("#lectureVideo");video.pause();video.src=VIDEO_URL;video.load();$("#videoOverlay").classList.remove("hide");$("#playPause").innerHTML='<i class="fa-solid fa-play"></i>';
  video.onloadedmetadata=()=>{if(resume&&history[id]?.time)video.currentTime=Math.min(history[id].time,video.duration||history[id].time);updatePlayerTime();};
  renderTranscript();renderNotes();renderBookmarks();setPlayerTab("notes");$("#playerModal").classList.remove("hidden");document.body.style.overflow="hidden";updateStats();
}
function closePlayer(){const video=$("#lectureVideo");video.pause();saveProgress();$("#playerModal").classList.add("hidden");document.body.style.overflow="";activeLecture=null;}
function playVideo(){const video=$("#lectureVideo");video.play().then(()=>$("#videoOverlay").classList.add("hide")).catch(()=>toast("Press play to start the sample video."));}
function updatePlayerTime(){const v=$("#lectureVideo");$("#timeDisplay").textContent=`${formatTime(v.currentTime)} / ${formatTime(v.duration)}`;$("#seekBar").value=v.duration?100*v.currentTime/v.duration:0;$("#noteTimestamp").textContent=formatTime(v.currentTime);highlightTranscript();}
function saveProgress(){if(!activeLecture)return;const v=$("#lectureVideo");if(v.currentTime>1){history[activeLecture.id]={time:v.currentTime,duration:v.duration||activeLecture.mins*60,updated:Date.now()};store.set("history",history);renderContinue();}}
function renderTranscript(){
  const l=activeLecture;$("#transcriptSearch").value="";
  $("#transcriptList").innerHTML=l.transcript.map(([time,text])=>`<div class="transcript-line" data-seek="${time}"><time>${time}</time><span>${escapeHTML(text)}</span></div>`).join("");
  $$(".transcript-line").forEach(line=>line.addEventListener("click",()=>seekTo(line.dataset.seek)));
}
function highlightTranscript(){
  if(!activeLecture)return;let current=0;activeLecture.transcript.forEach(([t],i)=>{if(toSeconds(t)<=$("#lectureVideo").currentTime)current=i});
  $$(".transcript-line").forEach((line,i)=>line.classList.toggle("active",i===current));
}
function toSeconds(t){const [m,s]=t.split(":").map(Number);return m*60+s;}
function seekTo(t){$("#lectureVideo").currentTime=typeof t==="string"?toSeconds(t):t;updatePlayerTime();}
function renderNotes(){
  const list=notes[activeLecture.id]||[];$("#notesList").innerHTML=list.length?list.slice().reverse().map(n=>`<div class="saved-item"><div class="saved-item-head"><button class="timestamp-button" data-note-seek="${n.time}">${formatTime(n.time)} <i class="fa-solid fa-arrow-up-right-from-square"></i></button><button class="delete-item" data-delete-note="${n.id}" title="Delete note"><i class="fa-solid fa-trash"></i></button></div><p>${escapeHTML(n.text)}</p><small>${new Date(n.created).toLocaleString()}</small></div>`).join(""):`<div class="empty-list"><i class="fa-regular fa-note-sticky"></i>No notes yet.<br>Capture an important idea while watching.</div>`;
  $$("[data-note-seek]").forEach(b=>b.addEventListener("click",()=>seekTo(Number(b.dataset.noteSeek))));
  $$("[data-delete-note]").forEach(b=>b.addEventListener("click",()=>{notes[activeLecture.id]=notes[activeLecture.id].filter(n=>n.id!==b.dataset.deleteNote);store.set("notes",notes);renderNotes();updateStats()}));
  updateStats();
}
function addNote(){const text=$("#noteInput").value.trim();if(!text){toast("Write a note before saving.");return;}const id=activeLecture.id;notes[id]??=[];notes[id].push({id:crypto.randomUUID(),time:Math.floor($("#lectureVideo").currentTime),text,created:Date.now()});store.set("notes",notes);$("#noteInput").value="";renderNotes();updateStats();toast("Timestamped note saved.");}
function addBookmark(){if(!activeLecture)return;const time=Math.floor($("#lectureVideo").currentTime);if(bookmarks.some(b=>b.lectureId===activeLecture.id&&Math.abs(b.time-time)<3)){toast("A bookmark already exists near this moment.");return;}bookmarks.push({id:crypto.randomUUID(),lectureId:activeLecture.id,time,label:`${activeLecture.title} · ${formatTime(time)}`,created:Date.now()});store.set("bookmarks",bookmarks);renderBookmarks();updateStats();toast(`Moment bookmarked at ${formatTime(time)}.`);}
function renderBookmarks(){
  if(!activeLecture)return;const list=bookmarks.filter(b=>b.lectureId===activeLecture.id);
  $("#playerBookmarksList").innerHTML=list.length?list.slice().reverse().map(b=>`<div class="saved-item"><div class="saved-item-head"><button class="timestamp-button" data-bookmark-seek="${b.time}">${formatTime(b.time)}</button><button class="delete-item" data-delete-bookmark="${b.id}"><i class="fa-solid fa-trash"></i></button></div><p>${escapeHTML(b.label)}</p></div>`).join(""):`<div class="empty-list"><i class="fa-regular fa-bookmark"></i>No bookmarks yet.<br>Save difficult concepts for quick revision.</div>`;
  $$("[data-bookmark-seek]").forEach(b=>b.addEventListener("click",()=>seekTo(Number(b.dataset.bookmarkSeek))));
  $$("[data-delete-bookmark]").forEach(b=>b.addEventListener("click",()=>{bookmarks=bookmarks.filter(x=>x.id!==b.dataset.deleteBookmark);store.set("bookmarks",bookmarks);renderBookmarks();updateStats()}));
  updateStats();
}
function setPlayerTab(tab){currentPlayerTab=tab;$$("[data-player-tab]").forEach(b=>b.classList.toggle("active",b.dataset.playerTab===tab));$("#notesTabContent").classList.toggle("hidden",tab!=="notes");$("#bookmarksTabContent").classList.toggle("hidden",tab!=="bookmarks");}
function openDrawer(type){
  $("#drawerTitle").textContent=type==="bookmarks"?"My bookmarks":"My notes";const content=$("#drawerContent");
  if(type==="bookmarks"){
    content.innerHTML=bookmarks.length?bookmarks.slice().reverse().map(b=>{const l=getLecture(b.lectureId);return `<div class="drawer-row"><div><b>${escapeHTML(l?.title||"Lecture")}</b><small>${formatTime(b.time)} · ${l?.dept||""}</small></div><button data-drawer-play="${b.lectureId}" data-drawer-time="${b.time}">Jump in</button></div>`}).join(""):`<div class="empty-list"><i class="fa-regular fa-bookmark"></i>No saved moments yet.</div>`;
  }else{
    const all=Object.entries(notes).flatMap(([id,arr])=>arr.map(n=>({...n,lectureId:id}))).sort((a,b)=>b.created-a.created);
    content.innerHTML=all.length?all.map(n=>{const l=getLecture(n.lectureId);return `<div class="drawer-row"><div><b>${escapeHTML(l?.title||"Lecture")}</b><small>${formatTime(n.time)} · ${escapeHTML(n.text)}</small></div><button data-drawer-play="${n.lectureId}" data-drawer-time="${n.time}">Review</button></div>`}).join(""):`<div class="empty-list"><i class="fa-regular fa-note-sticky"></i>Your timestamped notes will appear here.</div>`;
  }
  $$("[data-drawer-play]").forEach(b=>b.addEventListener("click",()=>{const id=b.dataset.drawerPlay,time=Number(b.dataset.drawerTime);$("#sideDrawer").classList.remove("open");$("#drawerBackdrop").classList.add("hidden");openPlayer(id);$("#lectureVideo").addEventListener("loadedmetadata",()=>seekTo(time),{once:true})}));
  $("#drawerBackdrop").classList.remove("hidden");$("#sideDrawer").classList.add("open");
}
function exportNotes(){
  if(!activeLecture)return;const l=activeLecture,arr=notes[l.id]||[];const lines=[`REELNEST — STUDY NOTES`,`Lecture: ${l.title}`,`Department: ${l.dept}`,`Professor: ${l.prof}`,"",...arr.map(n=>`[${formatTime(n.time)}] ${n.text}`)];
  const w=window.open("","_blank");if(!w){toast("Allow pop-ups to print your notes.");return;}
  w.document.write(`<html><head><title>${escapeHTML(l.title)} — Notes</title><style>body{font:14px Arial;padding:40px;color:#222}h1{font-size:22px}p{line-height:1.6;border-bottom:1px solid #ddd;padding:10px 0}.time{color:#d22;font-weight:bold}</style></head><body><h1>REELNEST — STUDY NOTES</h1><h2>${escapeHTML(l.title)}</h2><p>${escapeHTML(l.dept)} · ${escapeHTML(l.prof)}</p>${arr.map(n=>`<p><span class="time">${formatTime(n.time)}</span> — ${escapeHTML(n.text)}</p>`).join("")}<script>window.onload=()=>window.print()<\/script></body></html>`);w.document.close();
}
function setTheme(theme){document.body.dataset.theme=theme;store.set("theme",theme);$$(".theme-menu button").forEach(b=>b.classList.toggle("selected",b.dataset.theme===theme));$("#themeMenu").classList.remove("open");}
function init(){
  setTheme(store.get("theme","ember"));renderCatalog();renderContinue();updateStats();
  $$(".filter-tab").forEach(b=>b.addEventListener("click",()=>{activeFilter=b.dataset.filter;updateFilterButtons();renderCatalog()}));
  let searchDelay;$("#searchInput").addEventListener("input",e=>{const value=e.target.value;clearTimeout(searchDelay);searchDelay=setTimeout(()=>{searchTerm=value.trim().toLowerCase();renderCatalog()},180)});
  $("#themeTrigger").addEventListener("click",()=>$("#themeMenu").classList.toggle("open"));
  $$(".theme-menu button").forEach(b=>b.addEventListener("click",()=>setTheme(b.dataset.theme)));
  document.addEventListener("click",e=>{if(!e.target.closest(".theme-wrap"))$("#themeMenu").classList.remove("open")});
  $("#heroWatch").addEventListener("click",()=>openPlayer("cs2"));$("#syllabusButton").addEventListener("click",()=>$("#syllabusModal").classList.remove("hidden"));$("#syllabusStart").addEventListener("click",()=>{$("#syllabusModal").classList.add("hidden");openPlayer("cs2")});
  $$("[data-close]").forEach(b=>b.addEventListener("click",()=>$("#"+b.dataset.close).classList.add("hidden")));
  $("#saveNote").addEventListener("click",addNote);$("#bookmarkCurrent").addEventListener("click",addBookmark);$("#exportNotes").addEventListener("click",exportNotes);
  $$("[data-player-tab]").forEach(b=>b.addEventListener("click",()=>setPlayerTab(b.dataset.playerTab)));
  $("#bigPlay").addEventListener("click",playVideo);$("#playPause").addEventListener("click",()=>{const v=$("#lectureVideo");if(v.paused)playVideo();else v.pause()});
  $("#lectureVideo").addEventListener("play",()=>{$("#videoOverlay").classList.add("hide");$("#playPause").innerHTML='<i class="fa-solid fa-pause"></i>'});
  $("#lectureVideo").addEventListener("pause",()=>$("#playPause").innerHTML='<i class="fa-solid fa-play"></i>');
  $("#lectureVideo").addEventListener("timeupdate",()=>{updatePlayerTime();if(!saveTimer){saveTimer=setTimeout(()=>{saveProgress();saveTimer=null},5000)}});
  $("#lectureVideo").addEventListener("loadedmetadata",updatePlayerTime);
  $("#lectureVideo").addEventListener("ended",saveProgress);
  $("#seekBar").addEventListener("input",e=>{const v=$("#lectureVideo");if(v.duration)v.currentTime=v.duration*(Number(e.target.value)/100)});
  $("#skipBack").addEventListener("click",()=>seekTo(Math.max(0,$("#lectureVideo").currentTime-5)));$("#skipForward").addEventListener("click",()=>seekTo($("#lectureVideo").currentTime+5));
  $("#speedSelect").addEventListener("change",e=>$("#lectureVideo").playbackRate=Number(e.target.value));
  $("#fullscreenButton").addEventListener("click",()=>{const frame=$(".video-frame");if(document.fullscreenElement)document.exitFullscreen();else frame.requestFullscreen?.()});
  $("#pipButton").addEventListener("click",async()=>{try{if(document.pictureInPictureElement)await document.exitPictureInPicture();else if(document.pictureInPictureEnabled)await $("#lectureVideo").requestPictureInPicture();else toast("Picture-in-Picture is not supported in this browser.")}catch{toast("Picture-in-Picture could not start.")}});
  $("#transcriptSearch").addEventListener("input",e=>{$$(".transcript-line").forEach(line=>line.classList.toggle("hidden",!line.textContent.toLowerCase().includes(e.target.value.toLowerCase())))});
  $("#clearHistory").addEventListener("click",()=>{history={};store.set("history",history);renderContinue();toast("Watch history cleared.")});
  $$("[data-open-panel]").forEach(b=>b.addEventListener("click",()=>openDrawer(b.dataset.openPanel)));
  $("#closeDrawer").addEventListener("click",()=>{$("#sideDrawer").classList.remove("open");$("#drawerBackdrop").classList.add("hidden")});
  $("#drawerBackdrop").addEventListener("click",()=>{$("#sideDrawer").classList.remove("open");$("#drawerBackdrop").classList.add("hidden")});
  $("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
  $$(".nav-link[data-scroll]").forEach(b=>b.addEventListener("click",()=>{document.getElementById(b.dataset.scroll).scrollIntoView({behavior:"smooth"});$("#sidebar").classList.remove("open");$$(".nav-link").forEach(x=>x.classList.toggle("active",x===b))}));
  $("#noteInput").addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key==="Enter")addNote()});
  document.addEventListener("keydown",e=>{
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();$("#searchInput").focus()}
    if(e.key==="Escape"){if(!$("#playerModal").classList.contains("hidden"))closePlayer();$("#syllabusModal").classList.add("hidden");$("#sideDrawer").classList.remove("open");$("#drawerBackdrop").classList.add("hidden")}
    if(!$("#playerModal").classList.contains("hidden")&&!["INPUT","TEXTAREA","SELECT"].includes(document.activeElement.tagName)){
      if(e.code==="Space"){e.preventDefault();$("#playPause").click()}
      if(e.key==="ArrowLeft")seekTo(Math.max(0,$("#lectureVideo").currentTime-5));
      if(e.key==="ArrowRight")seekTo($("#lectureVideo").currentTime+5);
    }
  });

}
init();
